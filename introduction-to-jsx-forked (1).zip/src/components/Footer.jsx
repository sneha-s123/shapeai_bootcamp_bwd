import React from "react";
function Footer(){
  return (
<footer><p>
  copyright by shape ai @2021
  </p>
  </footer>
  );
}

export default Footer;