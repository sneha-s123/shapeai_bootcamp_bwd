import React from "react";

function List() {
  return (
    <ul>
      <li>First</li>
      <li>Second</li>
      <li>Third</li>
    </ul>
  );
}

export default List;
