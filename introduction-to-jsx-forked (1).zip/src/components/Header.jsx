import React from "react";
function Header(){
  return (
    <header>
      <h1>shape ai bootcamps</h1>
      </header>
  );
}

export default Header;